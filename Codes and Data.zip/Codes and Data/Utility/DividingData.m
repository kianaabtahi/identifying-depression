
function [TrainData,TrainLabel,TestData,TestLabel] = DividingData (Data,Label,train,test,batch_size)

    TrainData = Data(:,train);
    TrainLabel = Label(train);
    TestData = Data(:,test);
    TestLabel = Label(test);
    
    b = size(TrainData,2); 
    Address = b;
    
    while rem(Address, batch_size) ~=0 
        Address = Address-1;
    end
    
    TrainData = Data(:,1:Address);
    TrainLabel = Label(1:Address);
    TestData = Data(:,Address+1:end);
    TestLabel = Label(Address+1:end);
    
end