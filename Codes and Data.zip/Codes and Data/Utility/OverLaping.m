
function OverlapFactor = OverLaping(SegmentedImage,Output)
              
          nhood1 = true(100);
          Img = SegmentedImage(:,54:end-53,:);
          [m1,n1,p1] = size(Img);
          BaseRedChannel = zeros(m1,n1,p1);
          for i1 = 1 : m1
              for j1 = 1 : n1
                  for k1 = 1 : p1
                       
                      if Img(i1,j1,1)>240 & Img(i1,j1,2)<220 & Img(i1,j1,3)<220  
                          BaseRedChannel(i1,j1,1) = Img(i1,j1,1);
                      end
                      
                  end
              end
          end

          Y1 = BaseRedChannel(:,:,1)>100;
          closeBWao1 = imfill(Y1,'hole');
          
          CroppedImage =imresize(Output,[m1,n1]);
          %CroppedImage = ResIm(:,54:end-53,:);
          %CroppedImage = crop_img(img1,0);
          [m2,n2,p2] = size(CroppedImage);
          BaseBlueChannel = zeros(m2,n2,p2);
          for i2 = 1 : m2
              for j2 = 1 : n2
                  for k2 = 1 : p2
                       
                      if CroppedImage(i2,j2,1)<220 & CroppedImage(i2,j2,2)<220 & CroppedImage(i2,j2,3)>240  
                          BaseBlueChannel(i2,j2,3) = CroppedImage(i2,j2,3);
                      end
                      
                  end
              end
          end
          OutPutBlueChannel = BaseBlueChannel;
          Y2 = BaseBlueChannel(:,:,3)>100;
          closeBWao2 = imfill(Y2,'hole');
          
          OverlapFactor = OverlapCalculation(closeBWao1, closeBWao2);


end





