

function CountedPixelValues = CountedPixel (Image)
  
 [m,n]

end