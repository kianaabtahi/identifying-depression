
function [OutputImage,BWfinal,FireCenteroids,st] = PreProcessingStep(Image)

 ResImage = imresize(Image,1);
 J1 = imadjust(ResImage(:,:,1));
  J2 = imadjust(ResImage(:,:,2));
   J3 = imadjust(ResImage(:,:,3));
 J = cat(3,J1,J2,J3);
 
 ROIImage = redundancy_process(J);
 % Otsu Segmentation
% I_Otsu = im2bw(J,graythresh(J));
% Conversion to HIS
%I_HIS = rgb2hsi(J);

cform = makecform('srgb2lab');

lab_he = applycform(ResImage,cform);

ab = double(lab_he(:,:,2:3));
nrows = size(ab,1);
ncols = size(ab,2);
ab = reshape(ab,nrows*ncols,2);
nColors = 3;
[cluster_idx cluster_center] = kmeans(ab,nColors,'distance','sqEuclidean', ...
                                      'Replicates',3);
% Label every pixel in tha image using results from K means
pixel_labels = reshape(cluster_idx,nrows,ncols);

% Create a blank cell array to store the results of clustering
segmented_images = cell(1,3);
% Create RGB label using pixel_labels
rgb_label = repmat(pixel_labels,[1,1,3]);

for k = 1:nColors
    colors = ResImage;
    colors(rgb_label ~= k) = 0;
    segmented_images{k} = colors;
end
  
  X1 = segmented_images{1,1};
  X2 = segmented_images{1,2};
  X3 = segmented_images{1,3}; 

 % Fused = uint8(wfusimg(X1,X2,'sym4',5,'max','max'));
 %[~,OutputImage] = RGB2HSI(ResImage);
  CountedPixelValuesX1 = CountedZerosPixel (X1);
  CountedPixelValuesX2 = CountedZerosPixel (X2);
  CountedPixelValuesX3 = CountedZerosPixel (X3);
  
  [~,Index1] = max([CountedPixelValuesX1,CountedPixelValuesX2,CountedPixelValuesX3]);
  
  y1=imhist(X1);y11 = mean(y1(2:end));
  y2=imhist(X2);y22 = mean(y2(2:end));
  y3=imhist(X3);y33 = mean(y3(2:end));
  
  [~,Index2] = min([y11,y22,y33]);
        
  if Index1==1
      OutputImage = X1;
  elseif Index1==2
       OutputImage = X2;
  elseif Index1==3
      OutputImage = X3;
  end
  
       Im = imclearborder(OutputImage,4);
        A = im2bw(Im,graythresh(Im));
        I = bwareaopen(A, 50);
        st = regionprops(I,'all');
        ImageCenter = st.Centroid;
        FireCenteroids = cat(2, ImageCenter);
        
        [~,threshold] = edge(rgb2gray(Im),'sobel');
        fudgeFactor = 0.5;
        BWs = edge(rgb2gray(Im),'sobel',threshold * fudgeFactor);
        
        se90 = strel('line',3,90);
        se0 = strel('line',3,0);
        
        
        BWsdil = imdilate(BWs,[se90 se0]);
        BWdfill = imfill(BWsdil,'holes');
        BWnobord = imclearborder(BWdfill,4);
        seD = strel('diamond',2);
        BWfinal = imerode(BWnobord,seD);
        BWfinal = imerode(BWfinal,seD);
 
end



