function [ output_args ] = redundancy_process( input_args )

im1= medfilt2(rgb2gray(input_args),[8 8])>120;
% imshow(im1) 
% pause(.1)
im2 = bwareaopen(im1, round(0.01*(numel(im1))));
% imshow(im2)
% pause(.1)
im3 = ~bwareaopen(~im2, round(0.01*(numel(im1))));
% imshow(im3)
% pause(.1)
output_argsR=uint8(~im3).*input_args(:,:,1);
output_argsG=uint8(~im3).*input_args(:,:,2);
output_argsB=uint8(~im3).*input_args(:,:,3);
output_args = cat(3,output_argsR,output_argsG,output_argsB);
end

