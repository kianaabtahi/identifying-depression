

function CountedPixelValues = CountedZerosPixel (Image)
  
 [m,n,p] = size(Image);
 CountedPixelValues = 0;
 
 for i = 1:m
     for j = 1:n
         for k = 1 : p 
             
             if Image(i,j,k)<10
                 CountedPixelValues = CountedPixelValues+1;
             end
         end
     end
 end

end