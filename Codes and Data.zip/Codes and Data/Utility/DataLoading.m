function [Data,Label,Classes] = DataLoading(data,label,instanceDataAugmentation,featuresDataAugmentation)



   Data=data;
   
   [m,n] = size(Data);
   repData = Data';

   firstData = repmat(repData, (featuresDataAugmentation)^2*n,instanceDataAugmentation,1); 
   Label = repmat(label,instanceDataAugmentation,1); 
   Data = reshape(firstData,[featuresDataAugmentation*n featuresDataAugmentation*n instanceDataAugmentation*m]);
   Classes = {'Healthy','Mild Depression','Moderate Depression','Severe Depression'};


end





