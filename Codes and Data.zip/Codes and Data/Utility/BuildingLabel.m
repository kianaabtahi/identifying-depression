

function OutputLabel = BuildingLabel(ChangeTargets)  

y = ChangeTargets';
m = length(y);
kk = max(y);
NewLabel = zeros(m, kk);
NewLabel(sub2ind(size(NewLabel), [1:m], y)) = 1;

OutputLabel = NewLabel';
end
