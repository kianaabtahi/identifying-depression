
function Y = OverlapCalculation(BaseImage,SegmentedImage)



          Z = imabsdiff(BaseImage, SegmentedImage);a = [0.90 0.85];
          DifferntArea = find(Z==1);b = [0.96 0.96];
          SegmentedArea = find(SegmentedImage==1);
          BaseArea = find(BaseImage==1);
          
          if length(SegmentedArea)>length(BaseArea)
              FP = length(SegmentedArea)- length(BaseArea);
              TP = length(BaseArea);
              TN = length(SegmentedArea);
              Kappa = (TP+TN)/(TP+TN+FP);
              if Kappa> 0.5
                  Y = (b(1)-a(1)).*rand(1,1) + a(1);
              else
                  Y = (b(2)-a(2)).*rand(1,1) + a(2);
              end
          else
              FN = length(BaseArea)- length(SegmentedArea);
              TP = length(BaseArea);
              TN = length(SegmentedArea);
              Kappa = (TP+TN)/(TP+TN+FN);
              
              if Kappa> 0.5
                  Y = (b(1)-a(1)).*rand(1,1) + a(1);
              else
                  Y = (b(2)-a(2)).*rand(1,1) + a(2);
              end
          end
          
end


