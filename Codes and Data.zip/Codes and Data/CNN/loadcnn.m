function cnn1=loadcnn(filename)
%calls load to load variables
cnn1.namaste=1;
load(filename, 'cnn1')

